
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fstream>
#include <math.h>
#include <complex.h>
#include <algorithm>
////testing the fortran interface
extern "C" void Eprim(int nsource,int ntarget, double *rs,double* js,double* robs, double* Eprimary, double iprec);
extern "C" void Hprim(int nsource,int ntarget, double *rs,double* js,double* robs, double* Hprimary, double iprec);
extern "C" void Aprim(int nsource,int ntarget, double *rs,double* js,double* robs, double* Aprim,double*curlAprim, double iprec);
extern "C" void  computeeprimary_(double *rs,double *js,double* robs,double* Eprimary,int *ntarget,int *npoints,double *iprec);
extern "C" void  computehprimary_(double *rs,double *js,double* robs,double* Eprimary,int *ntarget,int *npoints,double *iprec);
extern "C" void  computeaprimary_(double *rs,double *js,double* robs,double* Aprimary,double* curlAprimary,int *ntarget,int *npoints,double *iprec);

void Eprim(int nsource,int ntarget, double *rs,double* js,double* robs, double* Eprimary,double iprec) {


computeeprimary_(rs,js,robs,Eprimary,&ntarget,&nsource,&iprec);
}

void Hprim(int nsource,int ntarget, double *rs,double* js,double* robs, double* Hprimary,double iprec) {


computehprimary_(rs,js,robs,Hprimary,&ntarget,&nsource,&iprec);
}

void Aprim(int nsource,int ntarget, double *rs,double* js,double* robs, double* Aprimary,double* curlAprimary,double iprec) {


computeaprimary_(rs,js,robs,Aprimary,curlAprimary,&ntarget,&nsource,&iprec);
}
